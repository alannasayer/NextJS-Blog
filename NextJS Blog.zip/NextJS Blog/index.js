import Link from 'next/link';

<h1 className={styles.title}>
  Read <Link href="/posts/first-post">this page!</Link>
</h1>